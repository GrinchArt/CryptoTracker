﻿namespace CryptoTracker.Application.Dto
{
    public class MarketDto
    {
        public string Name { get; set; }
        public string TradingPair { get; set; }
        public decimal Price { get; set; }
    }
}
