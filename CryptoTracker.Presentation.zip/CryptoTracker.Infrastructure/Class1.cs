﻿namespace CryptoTracker.Infrastructure
{
    public class Class1
    {

    }
}
